import './bootstrap';
import 'flowbite';