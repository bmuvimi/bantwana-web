@extends('layouts.default')
<section class="w-full mt-16">
    <img src="{{URL::to('/assets/img/slider-3.jpg')}}" alt="">
</section>